/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pinadivinador;

import java.io.Console;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Aldo
 */
public class PINAdivinador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner entrada_sc = new Scanner(System.in);
        String pin = JOptionPane.showInputDialog("Dame un pin de 4 digitos (0-9):");
        int contador = 0, contador_validar = 0;
        Integer pin_numero = 0;
        if(pin.length() != 4){
            //JOptionPane.showMessageDialog(null, "Lo siento pero debe de ser un pin de 4");    
            System.out.println("Lo siento pero debe ser un pin de 4 digitos");
        }
        else{
            for (int i = 0; i < 4; i++) {
                if(pin.charAt(i) == '0' || pin.charAt(i) == '1' || pin.charAt(i) == '2' || pin.charAt(i) == '3' || pin.charAt(i) == '4' || pin.charAt(i) == '5' || pin.charAt(i) == '6' || pin.charAt(i) == '7' || pin.charAt(i) == '8' || pin.charAt(i) == '9'){
                    contador_validar++;
                }
                else{
                    if(contador==0){
                        //JOptionPane.showMessageDialog(null, "Lo lamento pero detectamos un caracter que no es numero");
                     System.out.println("Lo lamento pero detectamos un caracter que no es un numero");
                    }
                    contador++;
                }
            }
            
            if(contador_validar == 4){
                System.out.println("Estamos generando el pin ingresado");
                pin_numero = Integer.parseInt(pin);
                
                if((pin_numero %2) == 0){
                    for (int i = 0; i <= pin_numero; i+=2) {
                        if(i == pin_numero){
                            //JOptionPane.showMessageDialog(null, "El numero es igual a : "+i);
                            System.out.println("El numero es igual " +i);
                        }
                    }
                }
                else{
                    for (int i = 1; i <= pin_numero; i+=2) {
                        if(i == pin_numero){
                            //JOptionPane.showMessageDialog(null, "El numero es igual a : "+i);
                             System.out.println("El numero es igual " +i);
                        }
                    }
                }
            }
        }
        
    }
    
}
